import numpy as np
import pandas as pd
import random
import time
import re
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from transformers import AutoModel, BertTokenizerFast, RobertaTokenizer, RobertaModel
from transformers import AdamW, get_linear_schedule_with_warmup
from tqdm import tqdm
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import classification_report
from sklearn.utils import shuffle


os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

SEED = 1234
batch_size = 128
epochs = 1

HIDDEN_DIM = 128
OUTPUT_DIM = 2
N_LAYERS = 2
BIDIRECTIONAL = True
DROPOUT = 0.25
ALPHA = 0.3
GAMMA = 2
LEARNING_RATE = 1e-4
WARM_UP = 0.1

train_path = "./SemEval_Task5/preprocess_train.csv"
dev_path = "./SemEval_Task5/preprocess_dev.csv"
test_path = "./SemEval_Task5/preprocess_test.csv"

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
setup_seed(SEED)

def sen_lable(sen_score):
    if sen_score < 0:
        return -1
    elif sen_score > 0:
        return 1
    else:
        return 0

# 小写字母
def lower_text(text):
    if type(text) != str:
        return text
    return (text.lower())

# def data_process(text):
#     text = re.sub("#(.*?)\ ", "", text)  
#     return text

# 数据集   
def build_dataset(path, if_test=False):    
    train_df_ = pd.read_csv(path)
    train_df_['label'] = train_df_['label'].astype('int')
    #train_df_['text'] = train_df_['text'].str.replace(r'[^\w\s]+', '')
    # train_df_['tweet'] = train_df_['tweet'].apply(lambda x:data_process(str(x)))
    #train_df_.drop_duplicates(subset='tweet', inplace=True)
    #train_df_['tweet'] = train_df_['tweet'].apply(lambda x:lower_text(x))
    train_df_ = train_df_.dropna()
    if not if_test:
        train_df_ = shuffle(train_df_)
    train_df = np.array(train_df_)
    text, label, sen_label = train_df[:, 0], train_df[:, 1], train_df[:, 2]
    #print(text)
    return text, label

train_text, train_labels = build_dataset(train_path)
val_text, val_labels = build_dataset(dev_path)
test_text, test_labels = build_dataset(test_path, if_test=True)

# import BERT-base pretrained model and tokenizer
bert = AutoModel.from_pretrained('bert-base-cased')
tokenizer = BertTokenizerFast.from_pretrained('bert-base-cased')
# import roberta
# tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
# bert = RobertaModel.from_pretrained('roberta-base')

def build_dataloader(text, label, max_length=50, pad_to_max_length=True, trunction=True):

    length = len(text.tolist())
    tokens = tokenizer.batch_encode_plus(
        text.tolist(),
        max_length = max_length,
        pad_to_max_length=pad_to_max_length,
        truncation=trunction
    )

    # convert lists to tensors
    seq = torch.tensor(tokens['input_ids'])
    mask = torch.tensor(tokens['attention_mask'])
    y = torch.tensor(label.tolist())
    data = TensorDataset(seq, mask, y)
    dataloader = DataLoader(data, batch_size = batch_size, shuffle = False)

    return length, dataloader

train_length, train_dataloader = build_dataloader(train_text, train_labels, max_length=45, pad_to_max_length=True, trunction=True)
dev_length, dev_dataloader = build_dataloader(val_text, val_labels, max_length=45, pad_to_max_length=True, trunction=True)
test_length, test_dataloader = build_dataloader(test_text, test_labels, max_length=45, pad_to_max_length=True, trunction=True)

# model
class BERT_Arch(nn.Module):
    def __init__(self, bert):
        super(BERT_Arch, self).__init__()
        self.bert = bert
        #self.fc1 = nn.Linear(768, 32)
        self.fc2 = nn.Linear(768, 1)
        self.dropout = nn.Dropout(0.5)
        self.softmax = nn.LogSoftmax(dim=1)
        
    def forward(self, send_id, mask):
        _, cls_hs = self.bert(send_id, attention_mask = mask)
        cls_hs = self.dropout(cls_hs)
        #x = self.fc1(cls_hs)
        x = self.fc2(cls_hs)
        #x = x.squeeze()
        #x = self.softmax(x) 
        x = x.squeeze(1)   
        #print(x.shape)    
        return x

#FocalLoss
class FocalLoss(nn.Module):
    def __init__(self, alpha=0.4, gamma=2, size_average=True):
        super(FocalLoss, self).__init__()
        self.alpha = torch.tensor(alpha)
        self.gamma = gamma
        self.size_average = size_average

    def forward(self, pred, target):

        device = target.device
        self.alpha = self.alpha.to(device)

        # 如果模型最后没有 nn.Sigmoid()，那么这里就需要对预测结果计算一次 Sigmoid 操作
        pred = nn.Sigmoid()(pred)

        # 展开 pred 和 target,此时 pred.size = target.size = (BatchSize,1)
        pred = pred.view(-1, 1)
        target = target.view(-1, 1)

        # 此处将预测样本为正负的概率都计算出来，此时 pred.size = (BatchSize,2)
        pred = torch.cat((1-pred, pred), dim=1)

        # 根据 target 生成 mask，即根据 ground truth 选择所需概率
        # 用大白话讲就是：
        # 当标签为 1 时，我们就将模型预测该样本为正类的概率代入公式中进行计算
        # 当标签为 0 时，我们就将模型预测该样本为负类的概率代入公式中进行计算
        class_mask = torch.zeros(pred.shape[0], pred.shape[1]).to(device)
        # 这里的 scatter_ 操作不常用，其函数原型为:
        # scatter_(dim,index,src)->Tensor
        # Writes all values from the tensor src into self at the indices specified in the index tensor.
        # For each value in src, its output index is specified by its index in src for dimension != dim and by the corresponding value in index for dimension = dim.
        class_mask.scatter_(1, target.view(-1, 1).long(), 1.)

        # 利用 mask 将所需概率值挑选出来
        probs = (pred * class_mask).sum(dim=1).view(-1, 1)
        probs = probs.clamp(min=0.0001, max=1.0)

        # 计算概率的 log 值
        log_p = probs.log()

        # 根据论文中所述，对 alpha　进行设置（该参数用于调整正负样本数量不均衡带来的问题）
        alpha = torch.ones(pred.shape[0], pred.shape[1]).to(device)
        alpha[:, 0] = alpha[:, 0] * (1 - self.alpha)
        alpha[:, 1] = alpha[:, 1] * self.alpha
        alpha = (alpha * class_mask).sum(dim=1).view(-1, 1)

        # 根据 Focal Loss 的公式计算 Loss
        batch_loss = -alpha * (torch.pow((1 - probs), self.gamma)) * log_p
 
        # Loss Function的常规操作，mean 与 sum 的区别不大，相当于学习率设置不一样而已
        if self.size_average:
            loss = batch_loss.mean()
        else:
            loss = batch_loss.sum()

        return loss

model = BERT_Arch(bert)
model.to(device)
# for name, param in model.named_parameters():
#     print(name,param.size())


optimizer = AdamW(model.parameters(),lr = LEARNING_RATE)  
#optimizer = optim.SGD(model.parameters(), lr = 1e-1)

class_weights = compute_class_weight('balanced', np.unique(train_labels), train_labels)
weights = torch.tensor(class_weights, dtype=torch.float)
weights = weights.to(device)

#criteon = nn.NLLLoss(weight=weights)
criteon = nn.BCEWithLogitsLoss()
##criteon = nn.NLLLoss()
# criteon = FocalLoss(ALPHA, GAMMA)

# total_steps = (train_length // batch_size) * epochs if train_length % batch_size == 0 else (train_length // batch_size + 1) * epochs
# warm_up_ratio =  WARM_UP
# scheduler = get_linear_schedule_with_warmup(
#     optimizer, num_warmup_steps = 0, num_training_steps = total_steps)

# 计算准确率
def binary_acc(preds, y):
    preds = torch.round(torch.sigmoid(preds))
    correct = torch.eq(preds, y).float()
    acc = correct.sum() / len(correct)
    return preds, acc

# def pred_lable(preds):
#     _, preds = torch.max(preds, 1) 
#     pred_lables = []
#     return pred_lables

# 训练函数
def train(model, iterator, optimizer, criteon, length):
    avg_loss = []
    avg_acc = []
    model.train()

    for i, batch in enumerate(tqdm(iterator)):
        batch = [r.to(device) for r in batch]
        sent_id, mask, label = batch
        pred = model(sent_id, mask)
        #print(pred.size())
        loss = criteon(pred, label.float())
        _, acc = binary_acc(pred, label)
        avg_loss.append(loss.item())
        avg_acc.append(acc.item())
                
        loss.backward()
        optimizer.step()
        #scheduler.step()
        optimizer.zero_grad()

    avg_loss = np.array(avg_loss).mean()
    avg_acc = np.array(avg_acc).mean()
    return avg_loss, avg_acc

# 评估函数
def eval(model, iterator, criteon):
    avg_loss = []
    avg_acc = []
    total_labels = []
    total_preds = []
    model.eval()

    with torch.no_grad():
        for i, batch in enumerate(tqdm(iterator)):
            batch = [r.to(device) for r in batch]
            sent_id, mask, label = batch
            pred = model(sent_id, mask)
            loss = criteon(pred, label.float())
            preds, acc = binary_acc(pred, label)
            avg_loss.append(loss.item())
            avg_acc.append(acc.item())

            pred_lables = preds.detach().cpu().numpy()
            label = label.detach().cpu().numpy()            
            total_preds.extend(pred_lables)
            total_labels.extend(label)

    avg_loss = np.array(avg_loss).mean()
    avg_acc = np.array(avg_acc).mean()
    print(total_labels[100:120])
    print(total_preds[100:120])
    print(classification_report(total_labels, total_preds, digits = 4))
    return avg_loss, avg_acc


#训练模型，并打印模型的表现
best_valid_acc = float('-inf')

for epoch in range(epochs):
    start_time = time.time()

    train_loss, train_acc = train(model, train_dataloader, optimizer, criteon, train_length)
    dev_loss, dev_acc = eval(model, dev_dataloader, criteon)

    end_time = time.time()

    epoch_mins, epoch_secs = divmod(end_time - start_time, 60)

    if dev_acc > best_valid_acc:          #只要模型效果变好，就保存
        best_valid_acc = dev_acc
        torch.save(model.state_dict(), 'wordavg-model_BERT.pt')

    print(f'Epoch: {epoch+1:02} | Epoch Time: {epoch_mins}m {epoch_secs:.2f}s')
    print(f'\tTrain Loss: {train_loss:.3f} | Train Acc: {train_acc*100:.2f}%')
    print(f'\t Val Loss: {dev_loss:.3f} |  Val Acc: {dev_acc*100:.2f}%')    

#用保存的模型参数预测数据
model.load_state_dict(torch.load("wordavg-model_BERT.pt"))
test_loss, test_acc = eval(model, test_dataloader, criteon)
print(f'Test Loss: {test_loss:.3f} |  Test Acc: {test_acc*100:.2f}%')
